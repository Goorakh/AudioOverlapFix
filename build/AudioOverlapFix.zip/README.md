# Audio Overlap Fix

A fix-all solution to unintentionally loud sounds, prevents the same sound from being played more than once within the span of a frame.

A per-sound cooldown value can also be configured (eg. same sound cannot be played more than once every X seconds).